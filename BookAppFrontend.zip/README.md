## React Project

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

- Command to check code deploy agent logs
sudo cat /var/log/aws/codedeploy-agent/codedeploy-agent.log